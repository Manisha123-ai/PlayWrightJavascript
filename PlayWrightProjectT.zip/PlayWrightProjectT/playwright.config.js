// @ts-check
import { defineConfig, devices } from '@playwright/test';
import { TIMEOUT } from 'dns/promises';

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// import dotenv from 'dotenv';
// import path from 'path';
// dotenv.config({ path: path.resolve(__dirname, '.env') });

/**
 * @see https://playwright.dev/docs/test-configuration
 */
// @ts-check
const Config = {
    testDir: './tests',
    fullyParallel: false,
    retries: 1,
    timeout: 30000,

    reporter: [
        ['list'],
        ['html'],
        ['allure-playwright']
    ],

    use: {
        browserName: 'chromium',
        headless: false,
        screenshot: 'only-on-failure',
        video: 'retain-on-failure',
    }
};

module.exports = Config;

