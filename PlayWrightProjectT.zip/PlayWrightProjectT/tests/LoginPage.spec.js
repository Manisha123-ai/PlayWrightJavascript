const { test, expect } = require('@playwright/test');

test('UI Basic Test', async ({ browser }) => {

    const context = await browser.newContext();
    const page = await context.newPage();

    await page.goto('https://rahulshettyacademy.com/loginpagePractise/');
});

test('page Test', async ({ page }) => {
    const username = page.locator('#username');
    const password = page.locator('#password');
    const signInBtn = page.locator('#signInBtn');
    await page.goto('https://rahulshettyacademy.com/loginpagePractise/');
    console.log(await page.title());
    await expect(page).toHaveTitle("LoginPage Practise | Rahul Shetty Academy");
    await page.locator('#username').fill('rahulshettyacademy');
    await page.locator('#password').fill('Learning@830$3mK2');
    await page.locator('#signInBtn').click();
    const allTitles = page.locator('.card-body a');
    console.log(await page.locator('.card-body a').first().textContent());
    console.log(await page.locator('.card-body a').nth(1).textContent());
    console.log(await page.locator('.card-body a').last().textContent());
    console.log(await allTitles.allTextContents());
});
test.only('Test by Using getBy', async ({ page }) => {
  
    await page.goto('https://rahulshettyacademy.com/loginpagePractise/');
    console.log(await page.title());
    await expect(page).toHaveTitle('LoginPage Practise | Rahul Shetty Academy');
    await page.getByRole('textbox', { name:'Username:'}).fill('rahulshettyacademy');
    await page.getByRole('textbox', { name:'Password:'}).fill('Learning@830$3mK2');
    await page.getByRole('button', { name: 'Sign In' }).click();
    const allTitles = page.locator('.card-body').getByRole('link');
    await expect(allTitles.first()).toBeVisible();
    await page.screenshot({ path: '1.png' });
    console.log(await allTitles.first().textContent());
    console.log(await allTitles.nth(1).textContent());
    console.log(await allTitles.last().textContent());
    console.log(await allTitles.allTextContents());
    await page.waitForLoadState('networkidle');

    });
